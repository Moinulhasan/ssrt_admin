<?php

namespace App\Repositories\Authentication;

interface AuthenticationRepositoryInterface
{

}
