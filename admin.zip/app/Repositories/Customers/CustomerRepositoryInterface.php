<?php

namespace App\Repositories\Customers;

interface CustomerRepositoryInterface
{

}
