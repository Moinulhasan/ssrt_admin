$(function() {
	'use strict'

var tooltip = new bootstrap.Tooltip(document.querySelector('[data-bs-toggle="tooltip"]'), {
    template: '<div class="tooltip" role="tooltip"><div class="arrow"><\/div><div class="tooltip-inner"><\/div><\/div>'
})

var tooltip = new bootstrap.Tooltip(document.querySelector('[data-bs-toggle="tooltip"]'), {
    template: '<div class="tooltip" role="tooltip"><div class="arrow"><\/div><div class="tooltip-inner"><\/div><\/div>'
})

var tooltip = new bootstrap.Tooltip(document.querySelector('[data-bs-toggle="tooltip"]'), {
    template: '<div class="tooltip" role="tooltip"><div class="arrow"><\/div><div class="tooltip-inner"><\/div><\/div>'
})

var tooltip = new bootstrap.Tooltip(document.querySelector('[data-bs-toggle="tooltip"]'), {
    template: '<div class="tooltip" role="tooltip"><div class="arrow"><\/div><div class="tooltip-inner"><\/div><\/div>'
})
});
