// $(function(e) {
// 	'use strict';
// 	$('#userDataTable').DataTable({
// 		responsive: true,
// 		// language: {
// 		// 	searchPlaceholder: 'Search...',
// 		// 	sSearch: '',
// 		// 	lengthMenu: '_MENU_ items/page',
// 		// }
//         "ajax": {
//             "url": "http://127.0.0.1:8000/api/all-user",
//             "type": "GET"
//         }
// 	});
// 	$('#datatable2').DataTable({
// 		bLengthChange: false,
// 		searching: false,
// 		responsive: true
// 	});
// 	// Select2
// 	$('.dataTables_length select').select2({
// 		minimumResultsForSearch: Infinity
// 	});
// });
