(function($) {
	"use strict";
	
	const ps11 = new PerfectScrollbar('.sidebar-right', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	

})(jQuery);