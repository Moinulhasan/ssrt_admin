(function($) {
	"use strict";
	
	const ps11 = new PerfectScrollbar('.sidebar-left', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	

})(jQuery);