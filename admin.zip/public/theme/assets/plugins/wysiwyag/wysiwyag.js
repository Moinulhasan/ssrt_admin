$(function (e) {
    $('.content').richText();
    $('#description').richText();
    $('#terms').richText();
    $('#redemption').richText();
    $('#expire').richText();
    $('.content2').richText();
    $('#tips-en').richText();
    $('#tips-ar').richText();
    $('#tips-fr').richText();
    $('#termSe').richText();
    $('#termSe1').richText();
    $('#termSe2').richText();
    $('.config').richText({skin: "rounded-corner", toolbar: "basic"});
    $('#description-en').richText();
    $('#description-fr').richText();
    $('#description-ar').richText();
});
